# Renegades XML Editor

Created by **Renegade9532**.

Renegades XML Editor is a Windows desktop editor for assigning custom GTA V add-on vehicle model names to Policing Redefined XML regions and special units. It reads supported, unencrypted add-on `dlc.rpf` archives, lets you assign one or more vehicles to one or more patrol zones, and writes cleanly formatted XML with vehicle chances totaling 100% per vehicle list.

## Features

- Import one or more `dlc.rpf` archives or folders containing them.
- Discover add-on vehicle models in nested RPF archives.
- Assign multiple vehicles to multiple Policing Redefined regions or special units.
- Preview supported native YFT/YTD vehicle assets in-app.
- Update `DefaultRegions.xml`, `SpecialUnits.xml`, and `CustomRegions.xml`.
- Preserve a readable XML layout, with one `<Vehicle>` entry per line.
- Use the interface in English, Spanish, French, German, Portuguese, or Russian.

## Build from source

Requirements:

- Windows
- .NET Framework 4.x Developer Pack / C# compiler at `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe`

Run the included PowerShell script:

```powershell
./Build-OpenSource.ps1
```

It creates `Release-OpenSource\Renegades XML Editor.exe`. The build is intentionally **not obfuscated**.

## Usage

1. Start `Renegades XML Editor.exe`.
2. Use **Agency setup** to find your Policing Redefined XML files.
3. Import a vehicle pack and select vehicles in **Assignments**.
4. Select one or more agencies/patrol zones and choose **Assign selected vehicles**.
5. Review your selections and choose **Import XML changes**. Back up your XML files first.

## Open-source status

This repository is released under the [MIT License](LICENSE). The release/source package contains the application’s native RPF, YFT, YTD, and preview implementation. It does not compile against or bundle CodeWalker.

## Support

Discord: `renegade9532`
